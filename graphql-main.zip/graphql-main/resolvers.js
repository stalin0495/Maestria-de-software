import { db } from './database.js';

/**
 * SOLUCIÓN OPTIMIZADA con DataLoader.
 * Cliente.facturas delega en el loader inyectado por petición en el context,
 * que agrupa todas las llamadas del mismo tick en una sola consulta por lote.
 */
export const resolvers = {
    Query: {
        clientes: async () => await db.fetchAllClientes(),
    },
    Cliente: {
        facturas: async (parent, _args, context) => {
            return await context.loaders.facturasLoader.load(parent.id);
        }
    }
};
