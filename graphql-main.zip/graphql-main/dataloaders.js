import DataLoader from 'dataloader';
import { db } from './database.js';

/**
 * Batch function: agrupa en una sola llamada todas las claves (clienteIds)
 * solicitadas durante el mismo tick y las resuelve con una única consulta IN (...).
 */
async function batchFacturasByClienteId(clienteIds) {
    return await db.fetchFacturasByClienteIdsBatch(clienteIds);
}

// Se exporta una fábrica, no una instancia global: cada petición HTTP debe
// tener su propio DataLoader para no compartir caché entre usuarios distintos.
export function createFacturasLoader() {
    return new DataLoader(batchFacturasByClienteId);
}
