import { db } from './database.js';

/**
 * SOLUCIÓN INGENUA (provoca el problema N+1).
 * Por cada cliente devuelto en Query.clientes, GraphQL invoca este resolutor
 * de forma independiente, generando 1 consulta a la BD por cliente (N consultas).
 * Se conserva solo como referencia didáctica; server.js NO usa este archivo.
 */
export const resolversNaive = {
    Query: {
        clientes: async () => await db.fetchAllClientes(),
    },
    Cliente: {
        facturas: async (parent) => {
            return await db.fetchFacturasByClienteId(parent.id);
        }
    }
};
