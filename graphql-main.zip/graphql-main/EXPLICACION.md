# Explicación de la Solución: Problema N+1 en GraphQL

## El problema

El equipo de Frontend de "LogiTech SaaS" necesita un dashboard que muestre clientes junto con sus facturas. Con REST esto exige **1 petición para listar clientes + N peticiones** (una por cada cliente) para traer sus facturas — esto es *under-fetching* y, trasladado a la capa de datos, se conoce como **problema N+1**.

En nuestro caso, con 5 clientes, un resolver GraphQL ingenuo ejecuta:
- 1 consulta `SELECT * FROM clientes`
- 5 consultas `SELECT * FROM facturas WHERE cliente_id = '...'` (una por cliente)

Total: **6 consultas** a la base de datos para una sola petición del cliente.

## La solución: patrón DataLoader

GraphQL permite pedir toda la información en **una sola petición HTTP**, pero el resolver de `Cliente.facturas` se sigue ejecutando una vez por cada cliente devuelto. El patrón **DataLoader** no cambia eso, pero **intercepta y agrupa** esas llamadas:

1. **Batching**: en vez de ir a la base de datos apenas se pide `.load(clienteId)`, DataLoader espera a que termine el "tick" actual de JavaScript, junta todas las claves solicitadas (`c-1, c-2, c-3, c-4, c-5`) y dispara **una sola consulta** `WHERE cliente_id IN (...)`.
2. **Caching por petición**: si la misma clave se pide dos veces en la misma request, se reutiliza el resultado ya cargado, sin golpear la base de datos otra vez.
3. **Instancia nueva por request**: el loader se crea dentro de `context` de Apollo Server, es decir, **un loader distinto para cada petición HTTP**. Esto evita que la caché de un usuario se filtre hacia otro.

Resultado: las 6 consultas originales se reducen a **2** (1 de clientes + 1 batch de facturas), sin importar cuántos clientes existan.

## Cómo quedó organizado el código

| Archivo | Qué contiene |
|---|---|
| [schema.graphql](schema.graphql) | El contrato SDL: tipos `Cliente`, `Factura` y la query `clientes`. |
| [database.js](database.js) | Simulación de base de datos, con el método `fetchFacturasByClienteIdsBatch` para traer facturas de varios clientes en un solo viaje. |
| [dataloaders.js](dataloaders.js) | La *batch function* y la fábrica `createFacturasLoader()` que crea un DataLoader nuevo por petición. |
| [resolvers.naive.js](resolvers.naive.js) | Resolver de referencia que **sí** provoca el problema N+1 (solo para comparar, no se usa en el servidor). |
| [resolvers.js](resolvers.js) | Resolver real y optimizado: `Cliente.facturas` llama a `context.loaders.facturasLoader.load(parent.id)`. |
| [server.js](server.js) | Arranca Apollo Server, carga el schema y crea el loader por petición en `context`. |

## Evidencia de que funciona

Al ejecutar la query de dashboard contra el servidor, la consola imprime exactamente:

```
[DB READ] SELECT * FROM clientes;
[DB BATCH READ] SELECT * FROM facturas WHERE cliente_id IN (c-1, c-2, c-3, c-4, c-5);
```

| Escenario | Consultas a la BD |
|---|---|
| Resolver ingenuo (sin DataLoader) | 1 + N = 6 |
| Resolver optimizado (con DataLoader) | 2 (fijo, no crece con N) |

## Conclusión

El problema N+1 no se resuelve cambiando el schema ni el contrato de la API — se resuelve en la capa de resolvers, agrupando las lecturas repetidas con DataLoader. Esto mantiene la ventaja de GraphQL (el cliente pide exactamente lo que necesita en una sola petición) sin sacrificar el rendimiento de la base de datos.
