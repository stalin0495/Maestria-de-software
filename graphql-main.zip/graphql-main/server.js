import { ApolloServer } from '@apollo/server';
import { startStandaloneServer } from '@apollo/server/standalone';
import { readFileSync } from 'node:fs';
import { fileURLToPath } from 'node:url';
import { dirname, join } from 'node:path';
import { resolvers } from './resolvers.js';
import { resolversNaive } from './resolvers.naive.js';
import { createFacturasLoader } from './dataloaders.js';

const __dirname = dirname(fileURLToPath(import.meta.url));

// RESOLVER_MODE=naive node server.js -> usa la versión con el problema N+1
const useNaive = process.env.RESOLVER_MODE === 'naive';
const activeResolvers = useNaive ? resolversNaive : resolvers;
console.log(`🧩 Modo de resolvers: ${useNaive ? 'INGENUO (N+1)' : 'OPTIMIZADO (DataLoader)'}`);

// 1. ESQUEMA (SDL) definido en archivo separado: schema.graphql
const typeDefs = readFileSync(join(__dirname, 'schema.graphql'), 'utf-8');

// 2. INICIALIZACIÓN DEL SERVIDOR
const server = new ApolloServer({ typeDefs, resolvers: activeResolvers });
const { url } = await startStandaloneServer(server, {
    listen: { port: 4000 },
    context: async () => ({
        // Un DataLoader nuevo por petición: evita fuga de caché entre usuarios.
        loaders: {
            facturasLoader: createFacturasLoader()
        }
    })
});
console.log(`🚀 Servidor Académico listo en: ${url}`);


